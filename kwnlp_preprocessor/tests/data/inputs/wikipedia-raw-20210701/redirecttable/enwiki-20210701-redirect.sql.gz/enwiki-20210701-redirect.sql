-- MySQL dump 10.18  Distrib 10.3.27-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 10.64.48.13    Database: enwiki
-- ------------------------------------------------------
-- Server version	10.4.18-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `redirect`
--

DROP TABLE IF EXISTS `redirect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `redirect` (
  `rd_from` int(8) unsigned NOT NULL DEFAULT 0,
  `rd_namespace` int(11) NOT NULL DEFAULT 0,
  `rd_title` varbinary(255) NOT NULL DEFAULT '',
  `rd_interwiki` varbinary(32) DEFAULT NULL,
  `rd_fragment` varbinary(255) DEFAULT NULL,
  PRIMARY KEY (`rd_from`),
  KEY `rd_ns_title` (`rd_namespace`,`rd_title`,`rd_from`)
) ENGINE=InnoDB DEFAULT CHARSET=binary ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `redirect`
--

/*!40000 ALTER TABLE `redirect` DISABLE KEYS */;
INSERT INTO `redirect` VALUES (10583,0,'Frodo_Baggins','',''),(15753,0,'Frodo_Baggins','',''),(22674,0,'Gandalf','',''),(63701,0,'Gimli_(Middle-earth)','',''),(157800,0,'Aragorn','','');INSERT INTO `redirect` VALUES (222692,0,'Legolas','',''),(290201,0,'Character_(arts)','','');INSERT INTO `redirect` VALUES (375178,0,'Character_(arts)','','');INSERT INTO `redirect` VALUES (414108,0,'Gandalf','',''),(421338,0,'Gandalf','','The White Council'),(448539,0,'Gandalf','',''),(452032,0,'Aragorn','',''),(496620,0,'Character_(arts)','','');INSERT INTO `redirect` VALUES (541321,0,'Merry_Brandybuck','',''),(541897,0,'Gandalf','',''),(547480,0,'Boromir','','The Two Towers'),(574760,0,'Aragorn','','');INSERT INTO `redirect` VALUES (614485,0,'Aragorn','',''),(670416,0,'Character_(arts)','',''),(676582,0,'Aragorn','','Isildur');INSERT INTO `redirect` VALUES (770028,0,'Gimli_(Middle-earth)','','');INSERT INTO `redirect` VALUES (840149,0,'Aragorn','',''),(887052,0,'Aragorn','','');INSERT INTO `redirect` VALUES (963056,0,'Aragorn','','Early life'),(1010030,0,'Character_(arts)','',''),(1037641,0,'Aragorn','','Isildur');INSERT INTO `redirect` VALUES (1224690,0,'Gandalf','','Gandalf the White');INSERT INTO `redirect` VALUES (1606117,0,'Frodo_Baggins','','');INSERT INTO `redirect` VALUES (1693954,0,'Character_(arts)','',''),(1693955,0,'Character_(arts)','','');INSERT INTO `redirect` VALUES (2213788,0,'Character_(arts)','','');INSERT INTO `redirect` VALUES (2808469,0,'Frodo_Baggins','','');INSERT INTO `redirect` VALUES (2985427,0,'Gandalf','','');INSERT INTO `redirect` VALUES (3321588,0,'Samwise_Gamgee','','');INSERT INTO `redirect` VALUES (3358605,0,'Pippin_Took','','');INSERT INTO `redirect` VALUES (3724594,0,'Merry_Brandybuck','',''),(3724598,0,'Merry_Brandybuck','',''),(3724689,0,'Pippin_Took','',''),(3724696,0,'Pippin_Took','',''),(3724716,0,'Samwise_Gamgee','',''),(3724723,0,'Samwise_Gamgee','',''),(3724765,0,'Samwise_Gamgee','',''),(3724776,0,'Pippin_Took','',''),(3724790,0,'Pippin_Took','','');INSERT INTO `redirect` VALUES (3816715,0,'Samwise_Gamgee','',''),(3816716,1,'Samwise_Gamgee','','');INSERT INTO `redirect` VALUES (4270325,0,'Samwise_Gamgee','',''),(4343956,0,'Aragorn','','');INSERT INTO `redirect` VALUES (4482095,0,'Gimli_(Middle-earth)','','');INSERT INTO `redirect` VALUES (4626386,0,'Gandalf','','The White Council');INSERT INTO `redirect` VALUES (4784466,0,'Aragorn','',''),(4836919,0,'Literary_element','',''),(4836942,0,'Literary_element','',''),(4836945,0,'Literary_element','','');INSERT INTO `redirect` VALUES (5232750,0,'Samwise_Gamgee','',''),(5232763,0,'Samwise_Gamgee','','');INSERT INTO `redirect` VALUES (5832383,0,'Gimli_(Middle-earth)','','');INSERT INTO `redirect` VALUES (5956853,0,'Character_(arts)','','Dynamic vs. static'),(5956913,0,'Character_(arts)','','Round vs. flat');INSERT INTO `redirect` VALUES (6902617,0,'Gimli_(Middle-earth)','','');INSERT INTO `redirect` VALUES (7100477,0,'Gandalf','','');INSERT INTO `redirect` VALUES (8088983,0,'Gandalf','','');INSERT INTO `redirect` VALUES (8178874,0,'Character_(arts)','','');INSERT INTO `redirect` VALUES (8555989,0,'Gimli_(Middle-earth)','',''),(8628497,0,'Gimli_(Middle-earth)','','');INSERT INTO `redirect` VALUES (8678773,0,'Gandalf','','');INSERT INTO `redirect` VALUES (9037792,0,'Character_(arts)','',''),(9145512,0,'Gandalf','','');INSERT INTO `redirect` VALUES (10151888,0,'Legolas','','');INSERT INTO `redirect` VALUES (10320416,0,'Gimli_(Middle-earth)','',''),(10320417,1,'Gimli_(Middle-earth)','','');INSERT INTO `redirect` VALUES (10900970,0,'Character_(arts)','','');INSERT INTO `redirect` VALUES (11404840,0,'Character_(arts)','','Round vs. flat');INSERT INTO `redirect` VALUES (11910723,0,'Pippin_Took','','Fool of a Took');INSERT INTO `redirect` VALUES (12131159,0,'Character_(arts)','','');INSERT INTO `redirect` VALUES (12249894,0,'Aragorn','','Concept and creation'),(12275360,0,'Merry_Brandybuck','','Names and titles');INSERT INTO `redirect` VALUES (12551803,0,'Frodo_Baggins','','');INSERT INTO `redirect` VALUES (12992419,0,'Aragorn','','Concept and creation'),(12992420,1,'Aragorn','','');INSERT INTO `redirect` VALUES (13257905,0,'Character_(arts)','','Regular, recurring and guest characters'),(13257909,0,'Character_(arts)','','Regular, recurring and guest');INSERT INTO `redirect` VALUES (13502071,0,'Character_(arts)','','');INSERT INTO `redirect` VALUES (14129968,0,'Aragorn','','');INSERT INTO `redirect` VALUES (14317391,0,'Aragorn','','Isildur');INSERT INTO `redirect` VALUES (15277147,0,'Frodo_Baggins','',''),(15350141,0,'Character_(arts)','','Dynamic vs. static'),(15350143,0,'Character_(arts)','','Dynamic vs. static'),(15350164,0,'Character_(arts)','','Dynamic vs. static');INSERT INTO `redirect` VALUES (17330181,0,'Character_(arts)','','Character as symbol');INSERT INTO `redirect` VALUES (17912753,1,'Character_(arts)','',''),(18023101,0,'Samwise_Gamgee','','');INSERT INTO `redirect` VALUES (18559820,0,'Aragorn','','');INSERT INTO `redirect` VALUES (18716004,0,'Gandalf','','');INSERT INTO `redirect` VALUES (19302157,0,'Character_(arts)','',''),(19302158,1,'Character_(arts)','','');INSERT INTO `redirect` VALUES (21549516,0,'Gandalf','',''),(21549549,0,'Gandalf','',''),(21549555,0,'Gandalf','','');INSERT INTO `redirect` VALUES (22256240,0,'Character_(arts)','','');INSERT INTO `redirect` VALUES (23225993,0,'Aragorn','','Isildur');INSERT INTO `redirect` VALUES (23940548,0,'Gandalf','','');INSERT INTO `redirect` VALUES (25001287,0,'Frodo_Baggins','','');INSERT INTO `redirect` VALUES (25117333,0,'Frodo_Baggins','','');INSERT INTO `redirect` VALUES (27281792,0,'Pippin_Took','','');INSERT INTO `redirect` VALUES (30386781,0,'Gandalf','','Concept and creation');INSERT INTO `redirect` VALUES (30534800,0,'Samwise_Gamgee','','Names and titles');INSERT INTO `redirect` VALUES (31071350,0,'Aragorn','','');INSERT INTO `redirect` VALUES (31594029,0,'Character_(arts)','','');INSERT INTO `redirect` VALUES (32053490,0,'Gandalf','','');INSERT INTO `redirect` VALUES (32110964,0,'Merry_Brandybuck','','');INSERT INTO `redirect` VALUES (34656550,0,'Aragorn','','');INSERT INTO `redirect` VALUES (36403578,0,'Pippin_Took','','');INSERT INTO `redirect` VALUES (37613727,0,'Gandalf','','');INSERT INTO `redirect` VALUES (38074269,0,'Boromir','','Walking into Mordor');INSERT INTO `redirect` VALUES (41302213,0,'Character_(arts)','',''),(41368809,0,'Gandalf','','');INSERT INTO `redirect` VALUES (50050672,0,'Character_(arts)','','Regular, recurring and guest characters'),(50050859,0,'Character_(arts)','','Regular, recurring and guest characters');INSERT INTO `redirect` VALUES (50895600,0,'Character_(arts)','','Regular, recurring and guest characters');INSERT INTO `redirect` VALUES (51905817,0,'Character_(arts)','',''),(51905825,0,'Character_(arts)','',''),(51905827,0,'Character_(arts)','',''),(51905832,0,'Character_(arts)','','');INSERT INTO `redirect` VALUES (54042910,0,'Character_(arts)','','');INSERT INTO `redirect` VALUES (62480381,0,'Gandalf','','The White Council');INSERT INTO `redirect` VALUES (62679715,0,'Gandalf','','The Lord of the Rings');INSERT INTO `redirect` VALUES (62808093,0,'Merry_Brandybuck','','');INSERT INTO `redirect` VALUES (62964959,0,'Merry_Brandybuck','',''),(62964960,1,'Merry_Brandybuck','',''),(62964969,0,'Pippin_Took','',''),(62964970,1,'Pippin_Took','','');INSERT INTO `redirect` VALUES (63978536,0,'Samwise_Gamgee','','Fictional biography'),(63987250,0,'Samwise_Gamgee','','Fictional biography');INSERT INTO `redirect` VALUES (64098418,0,'Pippin_Took','','Fool of a Took');INSERT INTO `redirect` VALUES (67215574,0,'Aragorn','',''),(67215579,0,'Aragorn','','');INSERT INTO `redirect` VALUES (68017582,0,'Merry_Brandybuck','','Family');/*!40000 ALTER TABLE `redirect` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-07-01  9:56:01
