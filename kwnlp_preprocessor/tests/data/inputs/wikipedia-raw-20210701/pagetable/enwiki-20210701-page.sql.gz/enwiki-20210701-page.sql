-- MySQL dump 10.18  Distrib 10.3.27-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 10.64.48.13    Database: enwiki
-- ------------------------------------------------------
-- Server version	10.4.18-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `page`
--

DROP TABLE IF EXISTS `page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page` (
  `page_id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `page_namespace` int(11) NOT NULL DEFAULT 0,
  `page_title` varbinary(255) NOT NULL DEFAULT '',
  `page_restrictions` tinyblob DEFAULT NULL,
  `page_is_redirect` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `page_is_new` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `page_random` double unsigned NOT NULL DEFAULT 0,
  `page_touched` varbinary(14) NOT NULL,
  `page_links_updated` varbinary(14) DEFAULT NULL,
  `page_latest` int(8) unsigned NOT NULL DEFAULT 0,
  `page_len` int(8) unsigned NOT NULL DEFAULT 0,
  `page_content_model` varbinary(32) DEFAULT NULL,
  `page_lang` varbinary(35) DEFAULT NULL,
  PRIMARY KEY (`page_id`),
  UNIQUE KEY `name_title` (`page_namespace`,`page_title`),
  KEY `page_random` (`page_random`),
  KEY `page_len` (`page_len`),
  KEY `page_redirect_namespace_len` (`page_is_redirect`,`page_namespace`,`page_len`)
) ENGINE=InnoDB AUTO_INCREMENT=68103379 DEFAULT CHARSET=binary ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page`
--

/*!40000 ALTER TABLE `page` DISABLE KEYS */;
INSERT INTO `page` VALUES (53221,0,'Gandalf','',0,0,0.49214563843993997,'20210629135708','20210629135919',1028931505,55754,'wikitext',NULL);INSERT INTO `page` VALUES (61599,0,'Boromir','',0,0,0.0608149320453544,'20210629135709','20210629140210',1027326693,24808,'wikitext',NULL),(62320,0,'Samwise_Gamgee','',0,0,0.36389867529636105,'20210629135709','20210629142009',1029042370,18488,'wikitext',NULL);INSERT INTO `page` VALUES (76749,0,'Character_(arts)','',0,0,0.389048659605019,'20210629135710','20210629135746',1030722887,22459,'wikitext',NULL);INSERT INTO `page` VALUES (450998,0,'Literary_element','',0,0,0.002505007201,'20210621195457','20210615060553',1023574900,5172,'wikitext',NULL);INSERT INTO `page` VALUES (20599055,0,'Gimli_(Middle-earth)','',0,0,0.043887001847,'20210626185312','20210621090821',1029662799,17345,'wikitext',NULL);INSERT INTO `page` VALUES (21920404,0,'Merry_Brandybuck','',0,0,0.092606963672,'20210626185733','20210622120356',1029849660,19045,'wikitext',NULL),(21920479,0,'Pippin_Took','',0,0,0.334696176766,'20210626185733','20210611133721',1011413198,14630,'wikitext',NULL);INSERT INTO `page` VALUES (23140032,0,'Frodo_Baggins','',0,0,0.796302799694,'20210626190005','20210626193411',1029850291,34662,'wikitext',NULL),(23140382,0,'Legolas','',0,0,0.29328594516,'20210626190005','20210611133329',1021951237,15509,'wikitext',NULL);/*!40000 ALTER TABLE `page` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-07-01  9:52:05
